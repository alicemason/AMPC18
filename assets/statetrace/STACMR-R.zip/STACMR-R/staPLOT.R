staPLOT <- function (data, pred=NULL)
  # function staPLOT (data, pred)
  # generates state-trace plot
# get stats from data (depending on its form)
if (is(data,"data.frame")) {
  y = gen2list (data) # convert from general format
  y = staSTATS (y, shrink) # get stats
} else if (is.null(data[[1]]$means)) {y = staSTATS(data, shrink) # in list form, get stats
} else {y = data} # already in stats form

nvar = length(y)