source ('staSTATS.R')
source ('gen2list.R')
source ('list2adj.R')
source ('adj2list.R')
source ('shrinkDiag.R')
source ('staMR.R')
source ('staCMRx.R')
source ('staCMRFIT.R')
source ('jMR.R')
source ('jCMRx.R')
source ('jCMRfitsx.R')

source ('BNframe2list.R')
source ('binSTATS.R')
source ('jCMRBN.R')
source ('staMRBN.R')
source ('staCMRBN.R')

source ('jMRfits.R')
source ('jMRBNfits.R')
source ('jCMRxBNfits.R')

if(require("magic")==F){install.packages ("magic"); library(magic)} 
if(require("rJava")==F){install.packages ("rJava"); library(rJava)}
.jinit(classpath="fxMR-0.3.35.jar", silent = FALSE)

