staSTATSBN = function(data=list()) {
  output = binSTATS(data)
  return (output)
}
