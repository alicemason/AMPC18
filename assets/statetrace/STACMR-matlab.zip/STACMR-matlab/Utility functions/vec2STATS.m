function y = vec2STATS (x, s, n)
% function y = vec2STATS (x, s, n)
% converts data in vector format to pseudo-staSTATS format (i.e. structured
% cell array)
% x = ncond*nvar matrix of means
% s = ncond*nvar matrix of standard deviations (optional)
% n = ncond*nvar matrix of no. of subjects (optional)
% assumes independent groups
%
if nargin < 3, n=[]; end
if nargin < 2, s=ones(size(x)); end
ncond = size(x,1); nvar = size(x,2);
y = cell(1,nvar);
for ivar=1:nvar
    y{ivar}.means = x(:,ivar);
    if isempty(n)
        y{ivar}.n = eye(ncond);
    else
        y{ivar}.n = diag(n(:,ivar));
    end
    y{ivar}.cov = diag(s(:,ivar).^2);
    y{ivar}.regcov = y{ivar}.cov;
    y{ivar}.shrinkage=0;
    if isempty(n)
        y{ivar}.weights = y{ivar}.cov^-1;
    else
        y{ivar}.weights = y{ivar}.n.*y{ivar}.cov^-1;
    end
    y{ivar}.lm = eye(ncond);
    y{ivar}.shrink=0;
end
