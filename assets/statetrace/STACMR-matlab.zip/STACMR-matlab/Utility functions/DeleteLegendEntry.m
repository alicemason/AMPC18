function DeleteLegendEntry (h)
set(get(get(h,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
